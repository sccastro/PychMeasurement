---
title: New Class Post
author: R package build
date: '2024-04-18'
slug: new-class-post
categories: []
tags: []
---

And anything I write here should be displayed. Now every time I save I can see it.



